# Security Policy

## Reporting a Vulnerability

If you find a vulnerability, contact us on contact+security@ethibox.fr
